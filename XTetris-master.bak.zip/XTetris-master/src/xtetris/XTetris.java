/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package xtetris;

/**
 *
 * @author darthleonard
 */
public class XTetris {
    public static void main(String[] args) {
        new MainFrame();
    }
}
